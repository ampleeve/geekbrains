<?php
<?php
/**
 * @var string $error
 */
?>

<p><?= $error; ?></p>