<?php
require_once ('../config.php');
echo renderPage(); // Данная функция определена в core.php, который подключен в config.php